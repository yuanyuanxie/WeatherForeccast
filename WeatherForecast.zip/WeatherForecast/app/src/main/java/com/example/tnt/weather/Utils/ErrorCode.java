package com.example.tnt.weather.Utils;

public class ErrorCode {
    public static String LOCATION_ERROR_CODE = "locationError";       // 位置信息错误
    // 天气信息获取状态码
    public static int weatherStatus = 1000;
    public static String weatherDesc = "OK";

}
