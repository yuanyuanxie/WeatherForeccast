package com.example.tnt.weather.Utils;

import android.os.Build;
import android.view.WindowManager;

public class StatusBar {
    public static int REQUEST_CODE_CHOOSE_LOCATION = 0x01;         // 请求选择城市页面的请求码
    public static int REQUEST_CODE_CITY_MANAGER_INITIAL= 0x02;         // 请求选择 城市管理 请求码
    public static int REQUEST_CODE_CITY_MANAGER= 0x03;         // 选择 城市管理 请求码

}
